time = int(input("Укажите время и я скажу вам день или ночь: "))
if time >= 6 and time <= 18:
    print("Сейчас день!")
else:
    print("Сейчас ночь!")
